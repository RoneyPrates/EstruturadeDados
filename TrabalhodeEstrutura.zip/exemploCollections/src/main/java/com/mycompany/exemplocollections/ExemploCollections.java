
package com.mycompany.exemplocollections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ExemploCollections {
    public static void main(String[] args) {
        List<String> lista = new ArrayList<>();

        lista.add("Maçã");
        lista.add("Banana");
        lista.add("Laranja");

        Collections.sort(lista);

        for (String elemento : lista) {
            System.out.println(elemento);
        }

        int posicao = Collections.binarySearch(lista, "Banana");
        System.out.println("A posição de Banana na lista é: " + posicao);
    }
}