package com.mycompany.exemplodelist;


import java.util.ArrayList;
import java.util.List;

public class ExemploList {
    public static void main(String[] args) {
        List<String> lista = new ArrayList<>();

        lista.add("Maçã");
        lista.add("Banana");
        lista.add("Laranja");


        for (String elemento : lista) {
            System.out.println(elemento);
        }

        lista.remove(1);

        for (String elemento : lista) {
            System.out.println(elemento);
        }
    }
}

