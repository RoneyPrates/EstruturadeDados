
package com.mycompany.exemploarraylist;

import java.util.ArrayList;

public class ExemploArrayList {
    public static void main(String[] args) {
        ArrayList<Integer> numeros = new ArrayList<>();

        numeros.add(10);
        numeros.add(20);
        numeros.add(30);

        for (int i : numeros) {
            System.out.println(i);
        }

        numeros.remove(1);

        for (int i : numeros) {
            System.out.println(i);
        }
    }
}
